package es.grupo.spring_api_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
