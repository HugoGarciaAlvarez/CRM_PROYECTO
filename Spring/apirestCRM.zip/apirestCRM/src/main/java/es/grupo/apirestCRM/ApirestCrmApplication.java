package es.grupo.apirestCRM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestCrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestCrmApplication.class, args);
	}

}
