import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common'; 
import { FormsModule } from '@angular/forms'; 

// 1. INTERFACES (Definiciones de datos)
interface Cliente {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  fechaRegistro: string; 
  estado: 'Activo' | 'Inactivo' | 'Pendiente';
}

interface NuevoCliente {
    nombre: string;
    email: string;
    telefono: string;
    estado: 'Activo' | 'Inactivo' | 'Pendiente';
}
